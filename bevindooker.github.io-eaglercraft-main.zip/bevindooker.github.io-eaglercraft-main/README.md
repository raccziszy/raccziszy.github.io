|||NOW UPDATED TO 1.8!!!!!

online version is https://svaaps.github.io/eaglercrafthtml/
(online version saves individual worlds too and works just as normal as the local version but you don't have to download anything)
if you wanna play eaglercraft locally, its in releases

you can also clone this to make your own copy of the web version of eaglercraft!

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/svaaps/eaglercrafthtml)
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2Fsvaaps%2Feaglercrafthtml%2F)


original repo link without html - https://github.com/lax1dude/eaglercraft

|||NOW UPDATED TO 1.8!!!!!


ps: thanks to all of you for forking my repo, it makes me happy and proud. ive never had these many people look at my repos :)
